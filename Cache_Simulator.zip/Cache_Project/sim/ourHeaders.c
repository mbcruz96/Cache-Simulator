// where our header functions will be defined
#include <stdio.h>

void hello_world(void)
{
    printf("Hello World!\n");
}